package com.example.lastcalcapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.calculatorapp.R;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button butonAdd, buttonSub, buttonMulti, buttonDiv;
    EditText firstVal, secondVal;
    TextView result;
    int num1, num2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        buttonAdd = findViewById(R.id.btnadd);
        buttonSub = findViewById(R.id.btnsubs);
        buttonMulti = findViewById(R.id.btnmultiply);
        buttonDiv = findViewById(R.id.btndivision);
        firstVal = findViewById(R.id.etfirstvalue);
        secondVal = findViewById(R.id.etsecondvalue);
        result = findViewById(R.id.tvresult);

        buttonAdd.setOnClickListener(this);
        buttonSub.setOnClickListener(this);
        buttonMulti.setOnClickListener(this);
        buttonDiv.setOnClickListener(this);

    }

    public int getIntFromEditText(EditText editText){
        if (editText.getText().toString().equals("")){
            Toast.makeText(this, "Enter numer", Toast.LENGTH_SHORT).show();
            return 0;
        }
        else
            return Integer.parseInt(editText.getText().toString());
    }


    @Override
    public void onClick(View view) {
        num1 = getIntFromEditText(firstVal);
        num2 = getIntFromEditText(secondVal);
        switch (view.getId()){
            case R.id.btnadd:
                result.setText("Answer = "+ (num1 + num2));
        }
    }
}